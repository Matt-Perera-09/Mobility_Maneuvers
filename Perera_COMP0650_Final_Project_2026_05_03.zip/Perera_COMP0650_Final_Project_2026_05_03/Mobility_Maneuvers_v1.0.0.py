### Mobility Maneuvers: Hollering Halls! ###

# - Coded using Pickcode and Pydroid 3

# - Available to view on Github

# 1. Game Foundation
import pygame
import sys
import random
import json # saves standard text data
import os # checks for a file on the hard drive

# 1.1. Initialize Pygame
pygame.display.init()

# 1.2. Screen dimensions (Canvas)

# Scan for current PC's OS
if sys.platform == "win32" or sys.platform == "darwin":
    # Mode: Windows or Mac (locked at 800x600)
    os.environ['SDL_VIDEO_CENTERED'] = '1'
    SCREEN_WIDTH = 800
    SCREEN_HEIGHT = 600
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    
else:
    # Mode: Chromebook and Mobile devices (stretch to fill the screen)
    screen = pygame.display.set_mode((800, 600))

    SCREEN_WIDTH = screen.get_width()
    SCREEN_HEIGHT = screen.get_height()

pygame.display.set_caption("Mobility Maneuvers: Hollering Halls!")

# 1.3. Core Variables
clock = pygame.time.Clock()
FPS = 60

# 1.4. Colors
white = (255, 255, 255)
blue = (0, 0, 255)
dark_gray = (50, 50, 50)
black = (0, 0, 0)
gold = (255, 160, 0)

# 1.5. Fonts for UI and scoring
pygame.font.init() # this keeps the font module active
sys_font = pygame.font.SysFont(None, 36) # sets default font size to '36'
tut_font = pygame.font.SysFont(None, 24)
instruct_font = pygame.font.SysFont(None, 24)

#1.6. Class List

class Door:
    def __init__(self, wall_margin, SCREEN_WIDTH):
        
        # Shorten the line so that it remains on the image "floor"
        floor_offset = 15 # May need tweaking...
        start_x = wall_margin + floor_offset
        
        # Calculate the width of the playable hallway
        width = SCREEN_WIDTH - (start_x * 2)
        
        # Currently a 50 px rectangle, spanning the wall; spawns out of view
        self.rect = pygame.Rect(start_x, -100, width, 50)
        self.color = (255, 215, 0, 100) # Gold finish line (RGBA: Red, Green, Blue, Alpha [shine])
        self.exact_y = float(-100)
        
        # Create a transparent finish line in place of the actual door
        self.surface = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        self.surface.fill(self.color)
        
    def update(self, scroll_amount):
        # The "door" comes down at the world scroll pace
        self.exact_y += scroll_amount
        self.rect.y = int(self.exact_y)
        
    def draw(self, screen):
        screen.blit(self.surface, self.rect)

class Player:
    def __init__(self):
        # A movable player square that is 32 x 32 px
        self.moving_left = False
        self.moving_right = False
        self.sprinting = False
        self.rect = pygame.Rect(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 100, 32, 32)
        self.color = blue
        
        # --- Dynamic Path Fix --- #
        
        # a. Ask Python to find the exact folder this image is saved in
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        
        # b. Assign the folder path to the player image file
        player_path = os.path.join(BASE_DIR, "Niki_A_Tyme_AlphPres.png")
        
        # c. Load the image via the path
        self.image = pygame.image.load(player_path).convert_alpha() # correct way to state file paths!
        self.image = pygame.transform.scale(self.image, (64, 64))
        
        # Base and boosted speeds
        self.base_speed = 2.0
        self.speed = self.base_speed
        
        # Boost end timer
        self.boost_end_time = 0
        self.sprint_multiplier = 2.0
        
        # Toggles hazard collisions 
        self.is_penalized = False

    def draw(self, screen):
        screen.blit(self.image, self.rect)

class Obstacle:
    def __init__(self, x, y, wall_margin):
        # A 32 x 32 pixel hazard
        self.rect = pygame.Rect(x, y, 32, 64)
        # self.color = (255, 0, 0) # Red for obstacles
        
        # --- Dynamic Path Fix --- #
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        obstacle_path = os.path.join(BASE_DIR, "default_obstacle_v02.png")
        
        # Load the image via path
        self.image = pygame.image.load(obstacle_path).convert_alpha()
        self.image = pygame.transform.scale(self.image, (32, 64))
        
        self.base_speed = 0.5 # Speed at which the obstacle moves towards the player.
        self.dx = random.choice([-1.5, 1.5]) # Slower horizontal speed
        self.wall_margin = wall_margin

        # Track exact position with floats
        self.exact_x = float(x)
        self.exact_y = float(y)

    def update(self, scroll_amount, SCREEN_WIDTH):
        
        # Obstacle moves at a speed of its own and the world's combined.
        self.exact_y += self.base_speed + scroll_amount
        self.exact_x += self.dx

        # Horizontal movement
        self.rect.y = int(self.exact_y)
        self.rect.x = int(self.exact_x)

        # Bounce off Walls
        if self.rect.left <= self.wall_margin:
            self.rect.left = self.wall_margin
            self.exact_x = float(self.rect.x) # Resyncs float after bounce
            self.dx *= -1 # Reverses direction
        
        elif self.rect.right >= SCREEN_WIDTH - self.wall_margin:
            self.rect.right = SCREEN_WIDTH - self.wall_margin
            self.exact_x = float(self.rect.x) # Resyncs float after bounce
            self.dx *= -1 # Reverses direction
            
    # self.image = pygame.image.load("phonehead.png").convert_alpha()
    # self.image = pygame.transform.scale(self.image, (self.rect.width, self.rect.height))

    #def draw(self, screen):
        #screen.blit(self.image, self.rect)

    def draw(self, surface):
        surface.blit(self.image, self.rect)
        
class Boost:
    def __init__(self, x, y):
        # A 16 x 16 item
        self.rect = pygame.Rect(x, y, 32, 32)
        # self.color = (0, 255, 0) # Green for boosts
        
        # --- Dynamic Path Fix --- #
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        boost_path = os.path.join(BASE_DIR, "boost_noodles_v02.png")
        
        # Load and scale
        self.image = pygame.image.load(boost_path).convert_alpha()
        self.image = pygame.transform.scale(self.image, (32, 32))
        
        # Position tracking for smooth movement
        self.exact_y = float(y)
        
        # Boosts come in slightly faster than the hallway
        self.base_speed = 1.0
        
    def update(self, scroll_amount):
        # Boosts move straight down
        self.exact_y += self.base_speed + scroll_amount
        self.rect.y = int(self.exact_y)
        
    def draw(self, surface):
        surface.blit(self.image, self.rect)
        
# --- Master Loop --- #
player_name = "" # Remember the player's name between plays.
play_again = True

# --- Music Loop --- #
pygame.mixer.init()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
music_path = os.path.join(BASE_DIR, "LaneOneVictory_GemAI_063594ae-65b1-468b-b98c-8a7e80bbfbee.mp3")

pygame.mixer.music.load(music_path)
pygame.mixer.music.play(-1) # Use -1 to loop the track infinitely

while play_again:

    # --- Section 2.0 --- # Environmental Variables
    
    # A background that scrolls down as the player moves, which gives the illusion of movement.
    bg_scroll_y = 0
    back_wall_y = SCREEN_HEIGHT - 200 # Independently tracks the starting wall
    base_scroll_speed = 2
    scroll_speed = base_scroll_speed
    
    # Walls on each side that are impassible within a distance.
    wall_margin = 150 # Change this value to adjust hallway width.
    
    # --- Dynamic Path Fix --- #
    
    # a. Ask Python for the exact folder the script resides in
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    # b. Attach the folder path to the file names
    hallway_path = os.path.join(BASE_DIR, "h1_main_v07.png")
    back_wall_path = os.path.join(BASE_DIR, "start_h1_hallway_v1.00_trimmed.png")
    player_path = os.path.join(BASE_DIR, "Niki_A_Tyme_AlphPres.png")
    
    # Loads the environment
    hallway_bg = pygame.image.load(hallway_path).convert_alpha()
    hallway_bg = pygame.transform.scale(hallway_bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
    
    back_wall_bg = pygame.image.load(back_wall_path).convert_alpha()
    back_wall_bg = pygame.transform.scale(back_wall_bg, (SCREEN_WIDTH, 200))
    
    # Create entities before the loop begins
    player = Player()
    
    # Obstacle Manager:
    active_obstacles = []
    
    # Custom Pygame event for spawning:
    last_obstacle_spawn_y = 0
    
    # Set distance to trigger the SPAWN_OBSTACLE event
    obstacle_spacing = 50
    
    # Boost Manager
    active_boosts = []
    
    # Boost spawner
    last_boost_spawn_y = 0
    
    # Set distance to spawn boosts
    boost_spacing = 200
    
    door = None
    door_spawned = False
    level_complete = False
    final_time = 0.0 # Variable can be determined here.
    
    # --- Menu and leaderboard variables
    # (obsolete) player_name = ""
    menu_running = True
    input_rect = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2, 200, 40)
    
    # Add a start button
    start_button = pygame.Rect(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 60, 100, 40)
    toggle_button = pygame.Rect(SCREEN_WIDTH //2 - 100, SCREEN_HEIGHT // 2 + 120, 200, 40)
    auto_sprint = False # False means Active Chair, True = Power Chair
    color_active = pygame.Color('lightskyblue3')
    color_passive = pygame.Color('chartreuse4')
    input_color = color_passive
    input_active = False
    
    # The mobile keyboard module is awoken by pygame\
    try:
        pygame.key.start_text_input()
    except AttributeError:
        pass # older pygame versions will ignore this
        
    
    # --- Menu Screen Loop ---
    while menu_running:
        screen.fill(dark_gray)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                
            # Click the mouse on input box
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Accessibility Mode option toggle
                if toggle_button.collidepoint(event.pos):
                    auto_sprint = not auto_sprint # toggles True or False
                # Tap the box
                if input_rect.collidepoint(event.pos):
                    input_active = True
                    input_color = color_active
                else:
                    input_active = False
                    input_color = color_passive
                
                # Tap the start button
                if start_button.collidepoint(event.pos):
                    if len(player_name) > 0: # It only starts if a name is typed
                        try:
                            pygame.key.stop_text_input() # Hides the mobile keyboard
                        except AttributeError:
                            pass
                        input_active = False # This locks the text box after name entry
                        menu_running = False
                        break # Instantly ends the menu loop to the nearest millisecond
                        
            # Capture text for Mobile devices and keyboard typing
            if event.type == pygame.TEXTINPUT:
                    if input_active:
                        # Only allow text that is a readable character
                        for char in event.text:
                            if char.isalnum() or char == " ":
                                player_name += char
                        
            if event.type == pygame.KEYDOWN:
                if input_active:
                    if event.key == pygame.K_RETURN:
                        # Exit the menu and start the game by pressing ENTER
                        if len(player_name) > 0:
                            try:
                                pygame.key.stop_text_input()
                            except AttributeError:
                                pass
                            input_active = False # Locks the text box after clicking ENTER
                            menu_running = False
                            break # Instantly ends the menu loop to the nearest millisecond
                    elif event.key == pygame.K_BACKSPACE:
                        # Only delete characters if there is one to delete
                        if len(player_name) > 0:
                        # Allows mistypes to be deleted
                            player_name = player_name[:-1]
                        # Allows typing of player names
                            # (removed due to conflict with text box typing on Chrome OS) player_name += event.unicode
     
        # --- Draws the menu text
        tut_line1 = tut_font.render("Get a feel for wheels as you navigate a crowded school hallway in a classic mobility device!", True, white)
        tut_line2 = tut_font.render(" Avoid distracted students and get to the hallway marker as fast as you can.", True, white)
        tut_line3 = tut_font.render("Pick up noodle cups to increase your speed for a short time and earn your place on the scoreboard!", True, white)
        screen.blit(tut_line1, (SCREEN_WIDTH // 2 - tut_line1.get_width() // 2, SCREEN_HEIGHT // 2 - 280))
        screen.blit(tut_line2, (SCREEN_WIDTH // 2 - tut_line2.get_width() // 2, SCREEN_HEIGHT // 2 - 240))
        screen.blit(tut_line3, (SCREEN_WIDTH // 2 - tut_line3.get_width() // 2, SCREEN_HEIGHT // 2 - 200))
        
        title_text = sys_font.render("Mobility Maneuvers: Hollering Halls!", True, gold)
        prompt_text = sys_font.render("Please click on the box, type your name, and press ENTER: ", True, white)
    
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, SCREEN_HEIGHT // 2 - 100))
        screen.blit(prompt_text, (SCREEN_WIDTH // 2 - prompt_text.get_width() // 2, SCREEN_HEIGHT // 2 - 50))
        
        # Bottom Menu text
        instruct_line1 = instruct_font.render("Active mode requires holding W or UP ARROW to increase speed.", True, white) 
        instruct_line2 = instruct_font.render("Power mode automatically runs at full speed.", True, white)
        instruct_line3 = instruct_font.render(" Both modes benefit from the Noodle Cup pickups.", True, white)
        screen.blit(instruct_line1, (SCREEN_WIDTH // 2 - instruct_line1.get_width() // 2, SCREEN_HEIGHT // 2 + 200))
        screen.blit(instruct_line2, (SCREEN_WIDTH // 2 - instruct_line2.get_width() // 2, SCREEN_HEIGHT // 2 + 240))
        screen.blit(instruct_line3, (SCREEN_WIDTH // 2 - instruct_line3.get_width() // 2, SCREEN_HEIGHT // 2 + 280))
        
        
        # Draws the text box
        pygame.draw.rect(screen, input_color, input_rect, 2)
        
        # Draws name in box
        name_surface= sys_font.render(player_name, True, white)
        screen.blit(name_surface, (input_rect.x + 5, input_rect.y + 5))
        
        # Resize the box to fit the name
        input_rect.w = max(200, name_surface.get_width() + 10)
        
        # Draws a start button
        button_color = (255, 140, 0)
        start_button = pygame.Rect(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 60, 100, 40)
        pygame.draw.rect(screen, button_color, start_button)
        start_text = sys_font.render("START", True, white)
        screen.blit(start_text, (start_button.x + 10, start_button.y + 10))
        
        # Toggles text on Accessibility button
        if auto_sprint:
            mode_text = sys_font.render("Mode: Power Wheelchair", True, white)
        else:
            mode_text = sys_font.render("Mode: Active Wheelchair", True, white)
    
        # Dynamic resizing of the button width
        text_rect = mode_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 140))
        # toggle_button.x = (SCREEN_WIDTH // 2) - (toggle_button.width // 2)
    
        # Enlarge the box (30px/w, 20px/h)
        toggle_button = text_rect.inflate(30, 20)
        
        # Draws the Accessibility button
        pygame.draw.rect(screen, color_passive, toggle_button)
    
        # Set toggle button text to centered
        screen.blit(mode_text, text_rect)
        
        pygame.display.flip()
        clock.tick(FPS)
        
    # --- End of menu loop ---
    
    # After the player presses enter...
    
    # Stamp the clock right before the game loop begins
    start_time = pygame.time.get_ticks()
    
    running = True
    
    # --- THE SINGLE MAIN GAME LOOP ---
    while running:
        # 1. Event handling.
        for event in pygame.event.get():
            
            # 1.1. Quit out
            if event.type == pygame.QUIT:
                running = False
                
                # Key compatibility for Chrome OS
                # Keys toggle 'on'
                # if event.type == pygame.KEYDOWN:
                    # if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                        # player.moving_left = True
                    # if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                        # player.moving_right = True
                    # if event.key == pygame.K_UP or event.key == pygame.K_w:
                        # player.sprinting = True
                    # print("Key registered: ", event.key)
                    
                # Keys toggle 'off'
                # if event.type == pygame.KEYUP:
                    # if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                        # player.moving_left = False
                    # if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                        # player.moving_right = False
                    # if event.key == pygame.K_UP or event.key -- pygame.K_w:
                        # player.sprinting = False
    
            # Spawn a new obstacle when the timer ticks.
            # if event.type == SPAWN_OBSTACLE:
                # Pick a random starting X position within the hallway.
                # spawn_x = random.randint(wall_margin, SCREEN_WIDTH - wall_margin - 32)
                # new_obstacle = Obstacle(spawn_x, -50, wall_margin)
                # active_obstacles.append(new_obstacle)
                
            # Spawn a new boost when the timer ticks.
            # if event.type == SPAWN_BOOST:
                # spawn_x = random.randint(wall_margin, SCREEN_WIDTH - wall_margin - 32)
                # new_boost = Boost(spawn_x, -50)
                # active_boosts.append(new_boost)
    
        # 2. Player Input/Movement.
        
        # Chrome OS compatible movement based on custom switches in # 1.
        # if player.moving_left:
            # player.rect.x -= player.speed
        # if player.moving_right:
            # player.rect.x += player.speed
                
        keys = pygame.key.get_pressed()
            
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            player.rect.x -= player.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            player.rect.x += player.speed
                
        # Wheelchair auto-scroll
        scroll_amount = scroll_speed
    
        if auto_sprint:
            # Accessibility Mode: Always move at max speed as if holding down the UP arrow or W key
            scroll_amount = scroll_speed * 2.0
        else:
            # Unassisted Mode: Hold the UP arrow, or W key (Win/Mac) to increase speed
            if keys[pygame.K_UP] or keys[pygame.K_w]:
                scroll_amount = scroll_speed * 2.0
                
        # Boost Fix
        scroll_amount = scroll_amount * player.sprint_multiplier
            
        # Chrome OS compatible sprint switch tracker
        # if player.sprinting:
            # scroll_amount = scroll_speed
            
        # if keys[pygame.K_UP] or keys[pygame.K_w]:
            # scroll_amount = scroll_speed
                
        # Adds scroll amount to background tracking
        bg_scroll_y += scroll_amount
        back_wall_y += scroll_amount # Moves the start/back wall down the screen
        
        # If the distance is greater than the space trigger, spawn a new obstacle
        if bg_scroll_y - last_obstacle_spawn_y >= obstacle_spacing:
            # Limit the number of obstacles on the screen
            if len(active_obstacles) < 10:
                spawn_x = random.randint(wall_margin, SCREEN_WIDTH - wall_margin - 64)
                new_obstacle = Obstacle(spawn_x, -50, wall_margin)
                active_obstacles.append(new_obstacle)
                
            # Resets tracker distance to the current location
            last_obstacle_spawn_y = bg_scroll_y
            
        # If the distance is greater than the space trigger, spawn a new boost
        if bg_scroll_y - last_boost_spawn_y >= boost_spacing:
            if len(active_boosts) < 1:
                spawn_x = random.randint(wall_margin, SCREEN_WIDTH - wall_margin - 64)
                new_boost = Boost(spawn_x, -50)
                active_boosts.append(new_boost)
                
            # Resets tracker distance to current location
            last_boost_spawn_y = bg_scroll_y
            
        # --- Boost Cooldown Checker ---
        # If boosted, check the clock
        if player.speed > player.base_speed:
            current_time = pygame.time.get_ticks()
            
            # If time expires, revert the speed to normal
            if current_time >= player.boost_end_time:
                player.speed = player.base_speed
                # Optional: testing expiration!
                print("That was fun!")
    
        # 3. Collision Detectors (Player and Walls)
        if player.rect.left < wall_margin:
            player.rect.left = wall_margin
        if player.rect.right > SCREEN_WIDTH - wall_margin:
            player.rect.right = SCREEN_WIDTH - wall_margin
    
        # 4. Environmental/Entity updates
        
        # Assume player is safe in each frame unless toggled
        player.is_penalized = False
        
        # We iterate over a copy of the list with [:] so we can safely remove the items.
        for obs in active_obstacles[:]:
            obs.update(scroll_amount, SCREEN_WIDTH)
    
            # Player collides with Obstacle.
            if player.rect.colliderect(obs.rect):
                player.is_penalized = True # Add collision logic here later!
                # print("Sorry, I did not see you there!")
                
            # Memory Manager: delete obstacle if it goes off the screen.
            if obs.rect.top > SCREEN_HEIGHT:
                active_obstacles.remove(obs)
                
            # Applies slowdown mechanics
            if player.is_penalized:
                # Reduce player movement speed significantly
                player.speed = 0.5
                scroll_speed = 0.25
            else:
                # Restore player default speed IF there are no active boosts
                if player.speed < player.base_speed:
                    player.speed = player.base_speed
                scroll_speed = base_scroll_speed
                
        # Iterate over a copied boosts list
        for boost in active_boosts[:]:
            boost.update(scroll_amount)
            
            # Detecting pickups
            if player.rect.colliderect(boost.rect):
                # Grant the boost
                # player.speed += 2 # increases player scroll speed
                
                # Expiration timer
                player.boost_end_time = pygame.time.get_ticks() + 2000
                
                # Boost removal
                active_boosts.remove(boost) # Removes the item on screen
    
            # Memory manager: delete offscreen
            elif boost.rect.top > SCREEN_HEIGHT:
                active_boosts.remove(boost)
    
            # New boost effect
            if pygame.time.get_ticks() < player.boost_end_time:
                player.sprint_multiplier = 2.0 # 2x faster scrolling
            else:
                player.sprint_multiplier = 1.0 # Normal speed
                
        # --- End door logic ---
        
        # 1. Spawn door at distance (14,400pxs/60s is an ideal scroll distance)
        if bg_scroll_y >= 14400 and not door_spawned:
            door = Door(wall_margin, SCREEN_WIDTH)
            door_spawned = True
            
        # 2. Update and draw the door
        if door_spawned:
            door.update(scroll_amount)
            
            # Detect the win condition
            if player.rect.colliderect(door.rect):
                # Determine the time (secs)
                final_time = (pygame.time.get_ticks() - start_time) / 1000.0
    
                level_complete = True
                running = False # ends the main game loop
    
        # 5. Drawing
        
        # Loads the background (back to front)
        screen.fill((0, 0, 0))
        
        # a. Modulo Trick: Infinite Hallway
        rel_y = int(bg_scroll_y) % SCREEN_HEIGHT
        
        # Draws an infinite loop from two copies of the hallway
        screen.blit(hallway_bg, (0, rel_y - SCREEN_HEIGHT))
        screen.blit(hallway_bg, (0, rel_y))
        
        # b. Draws the entry wall, beginning at the bottom and scrolling down
        # (obsolete) back_wall_y = (SCREEN_HEIGHT - 200) +bg_scroll_y
        
        # c. Only draws the entry wall if it would still be visible on-screen
        if back_wall_y < SCREEN_HEIGHT:
            screen.blit(back_wall_bg, (0, back_wall_y))
    
        # Draw wall boundaries
        pygame.draw.rect(screen, white, (0, 0, wall_margin, SCREEN_HEIGHT))
        pygame.draw.rect(screen, white, (SCREEN_WIDTH - wall_margin, 0, wall_margin, SCREEN_HEIGHT))
        
        # Draw the door if it has spawned
        if door_spawned:
            door.draw(screen)
    
        # Draw all active obstacles.
        for obs in active_obstacles:
            obs.draw(screen)
            
        # Draw all active boosts
        for boost in active_boosts:
            boost.draw(screen)
    
        player.draw(screen)
        
        # --> UI/Text Rendering <--
        
        # 5.1. Distance score calculation
        current_time = pygame.time.get_ticks()
        elapsed_seconds = (current_time - start_time) // 1000
        
        # - score = bg_scroll_y // 100
        
        # 5.2. Fully render the text in an image (text, anti-aliasing, colour)
        timer_text = sys_font.render(f"Time: {elapsed_seconds}s", True, black)
        
        # - score_text = sys_font.render(f"Distance: {score}m", True, black)
        
        # 5.3. Draw (blit) the text image on the screen at x = 10, y = 10 (top left screen corner)
        screen.blit(timer_text, (10, 10))
        
        # - screen.blit(score_text, (10, 10))
    
        # Frame Rendering
        pygame.display.flip()
        clock.tick(FPS)
    
    # --- Endgame Loop --- #
    end_running = True
    
    # Tells Windows where to read and write the JSON file
    if sys.platform == "win32" or sys.platform == "darwin":
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        scoreboard_file = os.path.join(BASE_DIR, "scoreboard.json")

    # Persistent Scoreboard
    scoreboard_file = "scoreboard.json"
    scores = []

    if level_complete:
        
        # --- Try/Catch Safety Net --- #
        
        # 6.3. Load any old scores first
        try:
            if os.path.exists(scoreboard_file):
                with open(scoreboard_file, "r", encoding="utf-8") as file:
                    scores = json.load(file)
                    
        # except json.JSONDecodeError:
            # print("Scoreboard file is corrupted. Starting anew!")
            # scores = [{"name": player_name, "time": final_time}]
        # except (PermissionError, FileNotFoundError, OSError) as e:
                # print(f"File Access has been blocked by Windows: {e}")
                
                # If Windows blocks the file, Python jumps here
                # print(f"Couldn't save scoreboard to Windows: {e}")
                # Backup Plan shows the player's current score without the scoreboard
                # scores = [{"name": player_name, "time": final_time}]
                
                # scores = [] # safety net if file is corrupt or empty

        # 6.4. Add the current player's new time to the list
            scores.append({"name": player_name, "time": final_time})

        # 6.4.1. Sort the list from shortest to longest time
            scores = sorted(scores, key=lambda x: x["time"])

        # 6.5. Updated list is saved back on the player's hard drive
            with open(scoreboard_file, "w") as file:
                json.dump(scores, file)

        # 6.6. The Catch
        except Exception as e: # Ignore the warning
            # If anything goes wrong, catch and print the error, but keep the game running.
            print(f"Bypassing file error to prevent crash: {e}")
            scores = [{"name": player_name, "time": final_time}]
    
    # Replay button (ellipse/oval)
    # Button belongs below the score board
    center_y = SCREEN_HEIGHT // 2
    button_y = center_y + 180
    
    replay_button = pygame.Rect(SCREEN_WIDTH // 2 - 210, button_y, 200, 50)
    replay_button_color = (255, 140, 0) # Light Orange 
    
    exit_button = pygame.Rect(SCREEN_WIDTH // 2 + 10, button_y, 200, 50)
    exit_button_color = (220, 20, 60) # Crimson 
    
    while end_running:
        screen.fill((30, 30, 50)) # Dark blue
    
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
    
            # Replay button click response
            if event.type == pygame.MOUSEBUTTONDOWN:
                if replay_button.collidepoint(event.pos):
                    print("Reloading Game... (logic pending!)")
                    end_running = False # end screen can be closed
                    
                # Exit button logic
                if exit_button.collidepoint(event.pos):
                    play_again = False # breaks the Master Loop to prevent a restart
                    end_running = False # breaks the End Loop so that the game exits
    
        # --- Endgame Text --- #
        
        # 0. Dynamic anchor point at the center of the monitor
        center_y = SCREEN_HEIGHT // 2
        
        # 1. Completion Praise
        congrats_text = sys_font.render(f"Congratulations {player_name}, you made it!", True, (255, 255, 255))
        screen.blit(congrats_text, (SCREEN_WIDTH // 2 - congrats_text.get_width() // 2, center_y - 200))
    
        # 2. Show end time and round to two decimals (only renders if the level is completed)
        if level_complete:
            time_text = sys_font.render(f"Finish Time: {final_time:.2f} seconds", True, (255, 255, 255))
            screen.blit(time_text, (SCREEN_WIDTH // 2 - time_text.get_width() // 2, center_y - 150))
            
        # 3. Scoreboard name
        title_text = sys_font.render("#-# TOP 5 Fastest Runs #-#", True, (255, 160, 0)) # Gold
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, center_y - 70))

        # Draw the scores
        if len(scores) == 0:
            empty_text = sys_font.render("No Recorded Times Yet!", True, (150, 150, 150))
            screen.blit(empty_text, (SCREEN_WIDTH // 2 - empty_text.get_width() // 2, center_y - 20))
        else:
            for i, entry in enumerate(scores[:5]):
                score_str = f"{i+1}. {entry['name']} - {entry['time']:.2f}s"
                score_surf = sys_font.render(score_str, True, (255, 255, 255))
                    
                # Ensures that the list is descending
                y_position = (center_y - 20) + (i * 30)
                    
                screen.blit(score_surf, (SCREEN_WIDTH // 2 - score_surf.get_width() // 2, y_position))
    
        # 3. Draw the replay button
        pygame.draw.ellipse(screen, replay_button_color, replay_button)
        play_text = sys_font.render("Play Again?", True, (255, 255, 255))
        text_x = replay_button.x + (replay_button.width - play_text.get_width()) // 2
        text_y = replay_button.y + (replay_button.height - play_text.get_height()) // 2
        screen.blit(play_text, (text_x, text_y))
        
        # 4. Draw the exit button
        pygame.draw.ellipse(screen, exit_button_color, exit_button)
        exit_text = sys_font.render("Exit?", True, (255, 255, 255))
        exit_x = exit_button.x + (exit_button.width - exit_text.get_width()) // 2
        exit_y = exit_button.y + (exit_button.height - exit_text.get_height()) // 2
        screen.blit(exit_text, (exit_x, exit_y))
    
        pygame.display.flip()
        clock.tick(FPS)

# --- Final Quit Game Logic --- #

# Clear the screen
screen.fill((30, 30, 50))

# Goodbye message
farewell_text = sys_font.render(f"Thank you for playing, {player_name}! See you around!", True, (255, 215, 0))
screen.blit(farewell_text, (SCREEN_WIDTH // 2 - farewell_text.get_width() // 2, SCREEN_HEIGHT // 2))

# Put the message onscreen
pygame.display.flip()

# Have the screen up for 5 seconds
pygame.time.delay(5000)

# Close safely
pygame.quit()
sys.exit()